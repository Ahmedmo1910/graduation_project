import os
import logging
import numpy as np
import cv2
import mediapipe as mp
from PIL import Image
from flask import Flask, request, jsonify
from flask_cors import CORS
from keras.applications import VGG16
from keras.applications.vgg16 import preprocess_input
from keras.layers import GlobalMaxPooling2D, Flatten, Dense, Dropout
from keras.models import Model
from keras import Input

# ── Logging ──────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("face_shape_api")

# ── Constants ─────────────────────────────────────────────────

MODEL_PATH      = os.path.join("model", "face_shape_final.h5")
CLASS_LABELS    = ["Heart", "Oblong", "Oval", "Round", "Square"]
IMAGE_SIZE      = (224, 224)
CONFIDENCE_THRESHOLD = 0.35
ALLOWED_EXTENSIONS   = {"jpg", "jpeg", "png", "webp"}
MIN_FILE_SIZE        = 1024  # bytes

# ── Model ─────────────────────────────────────────────────────

def build_model() -> Model:
    base = VGG16(
        weights=None,
        include_top=False,
        input_tensor=Input(shape=(224, 224, 3)),
    )
    x = base.output
    x = GlobalMaxPooling2D()(x)
    x = Flatten()(x)
    x = Dense(128, activation="relu")(x)
    x = Dropout(0.5)(x)
    out = Dense(len(CLASS_LABELS), activation="softmax")(x)
    return Model(inputs=base.input, outputs=out)


def load_model(path: str) -> Model:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Model weights not found at: {path}")
    m = build_model()
    m.load_weights(path)
    logger.info("Model weights loaded from %s", path)
    return m


model = load_model(MODEL_PATH)

# ── MediaPipe Face Detector ───────────────────────────────────

_mp_face = mp.solutions.face_detection
face_detector = _mp_face.FaceDetection(
    model_selection=1,
    min_detection_confidence=0.5,
)
logger.info("MediaPipe face detector ready.")

# ── Flask App ─────────────────────────────────────────────────

app = Flask(__name__)
CORS(app)

# ── Helpers ───────────────────────────────────────────────────

def _ext(filename: str) -> str:
    return filename.rsplit(".", 1)[-1].lower() if "." in filename else ""


def validate_upload(file) -> str | None:
    """Return an error message or None if the file is valid."""
    if not file or file.filename == "":
        return "No image provided."
    if _ext(file.filename) not in ALLOWED_EXTENSIONS:
        return f"Unsupported file type. Allowed: {', '.join(ALLOWED_EXTENSIONS)}."
    file.seek(0, 2)
    size = file.tell()
    file.seek(0)
    if size < MIN_FILE_SIZE:
        return "File is too small to be a valid image."
    return None


def detect_and_crop_face(image_bytes: bytes) -> tuple[Image.Image | None, str | None]:
    """Decode image bytes, run face detection, and return a cropped PIL image."""
    nparr = np.frombuffer(image_bytes, np.uint8)
    img_bgr = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    if img_bgr is None:
        return None, "Could not decode the image. The file may be corrupted."

    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    h, w = img_bgr.shape[:2]

    results = face_detector.process(img_rgb)
    if not results.detections:
        return None, "No face detected in the image."

    best = max(results.detections, key=lambda d: d.score[0])
    bb = best.location_data.relative_bounding_box

    x1 = int(bb.xmin * w)
    y1 = int(bb.ymin * h)
    x2 = int((bb.xmin + bb.width) * w)
    y2 = int((bb.ymin + bb.height) * h)

    mx = int((x2 - x1) * 0.20)
    my = int((y2 - y1) * 0.20)
    x1, y1 = max(0, x1 - mx), max(0, y1 - my)
    x2, y2 = min(w, x2 + mx), min(h, y2 + my)

    face_rgb = cv2.cvtColor(img_bgr[y1:y2, x1:x2], cv2.COLOR_BGR2RGB)
    return Image.fromarray(face_rgb), None


def preprocess_face(face: Image.Image) -> np.ndarray:
    """Resize and preprocess a PIL face crop for VGG16."""
    face = face.resize(IMAGE_SIZE)
    arr = np.array(face, dtype=np.float32)
    arr = np.expand_dims(arr, axis=0)
    return preprocess_input(arr)


# ── Routes ────────────────────────────────────────────────────

@app.get("/health")
def health():
    return jsonify({"status": "ok"}), 200


@app.post("/predict")
def predict():
    file = request.files.get("image")

    # ── Validate upload ──
    err = validate_upload(file)
    if err:
        logger.warning("Upload validation failed: %s", err)
        return jsonify({"error": err}), 400

    image_bytes = file.read()
    logger.info("Received image: %s (%d bytes)", file.filename, len(image_bytes))

    # ── Detect & crop face ──
    face, detection_err = detect_and_crop_face(image_bytes)
    if face is None:
        logger.warning("Face detection failed: %s", detection_err)
        return jsonify({"error": detection_err}), 422

    # ── Predict ──
    try:
        arr = preprocess_face(face)
        probs = model.predict(arr, verbose=0)[0]
        idx = int(np.argmax(probs))
        confidence = float(probs[idx])

        if confidence < CONFIDENCE_THRESHOLD:
            msg = "Face detected but shape is unclear. Please use a clearer front-facing photo."
            logger.warning("Low confidence (%.2f): %s", confidence, msg)
            return jsonify({"error": msg}), 422

        label = CLASS_LABELS[idx]
        logger.info("Prediction: %s (confidence=%.2f%%)", label, confidence * 100)

        return jsonify({
            "face_shape": label,
            "confidence": round(confidence * 100, 2),
        }), 200

    except Exception as exc:
        logger.exception("Prediction error: %s", exc)
        return jsonify({"error": "Prediction failed due to an internal error."}), 500


# ── Entry point ───────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)